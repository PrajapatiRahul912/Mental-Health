package com.example.wscube_logintutorial

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
